Sepura Font

People want to have a very personal font to represent themselves. A font that represents natural handwriting which usually looks dynamic, imperfect, random and casual. Sepura font presents a handwritten style based on brush strokes. With the automatic randomization feature, Sepura gives a natural feel like real handwriting. Each letter has six different characters so the scope of randomization is very wide.

There is also a catchwords feature that allows you to give different impressions on selected specific words. This font is suitable for posters, food and beverage packaging, games for children, book covers, t-shirts and much more.

---------------
(c)2022 Locomotype.com